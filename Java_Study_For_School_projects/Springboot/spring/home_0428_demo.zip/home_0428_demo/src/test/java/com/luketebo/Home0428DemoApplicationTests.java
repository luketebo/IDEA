package com.luketebo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Home0428DemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
