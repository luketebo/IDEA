package com.luketebo.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.luketebo.entity.Student;

public interface StudentService extends IService<Student> {
    Student getOne(Integer id);
}
