package com.luketebo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Home0428DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(Home0428DemoApplication.class, args);
    }

}
